/* Dibuat oleh Studio SCORM — isi kursus */
window.COURSE_DATA = {
 "title": "Pengenalan Alat Pelindung Diri (APD)",
 "description": "Kursus singkat ±10 menit: mengapa APD penting, jenis APD dasar, mengenali kondisi tidak aman, dan prosedur LOTO.",
 "version": "2004",
 "passingScore": 80,
 "navigation": "bebas",
 "certificate": true,
 "certificateIssuer": "Tim K3",
 "theme": {
  "accent": "#00704f",
  "accent2": "#ffc21a",
  "onAccent": "#ffffff",
  "bg": "#f2f5f0",
  "surface": "#ffffff",
  "ink": "#18222c",
  "muted": "#5d6871",
  "line": "#d8dfd6",
  "font": "modern",
  "transition": "geser"
 },
 "logo": null,
 "cover": "media/sampul.svg",
 "narration": {
  "browser": true,
  "autoplay": false,
  "voiceName": "",
  "rate": 1
 },
 "slides": [
  {
   "id": "s_pentingnya",
   "type": "content",
   "title": "Mengapa APD penting?",
   "narration": "",
   "audio": null,
   "body": "Alat Pelindung Diri (APD) melindungi pekerja dari bahaya yang **masih tersisa** setelah upaya pengendalian lain dilakukan.\n\nDalam hierarki pengendalian risiko, APD berada di urutan terakhir:\n\n1. Eliminasi — hilangkan bahayanya\n2. Substitusi — ganti dengan yang lebih aman\n3. Rekayasa teknik — pasang pengaman, isolasi sumber bahaya\n4. Administratif — prosedur, izin kerja, pelatihan\n5. APD — lapisan pertahanan terakhir\n\nArtinya, APD **wajib dipakai**, tetapi tidak boleh menjadi satu-satunya pengaman.",
   "image": "media/gambar-01.svg",
   "imageAlt": "Piramida hierarki pengendalian risiko: eliminasi, substitusi, rekayasa teknik, administratif, APD",
   "layout": "kanan"
  },
  {
   "id": "s_kartu",
   "type": "flip",
   "title": "Kenali APD dasar",
   "narration": "",
   "audio": null,
   "intro": "Ketuk setiap kartu untuk melihat fungsinya. Pilih APD sesuai bahaya yang tercantum di JSA/JSEA.",
   "requireAll": true,
   "cards": [
    {
     "front": "Helm keselamatan",
     "back": "Melindungi kepala dari benda jatuh dan benturan. Pakai tali dagu saat bekerja di ketinggian.",
     "image": "media/kartu-02-1.svg"
    },
    {
     "front": "Kacamata pengaman",
     "back": "Melindungi mata dari serpihan, percikan bahan kimia, dan gerinda.",
     "image": "media/kartu-02-2.svg"
    },
    {
     "front": "Sarung tangan",
     "back": "Pilih sesuai bahaya: tahan potong, tahan panas, atau tahan bahan kimia.",
     "image": "media/kartu-02-3.svg"
    },
    {
     "front": "Sepatu keselamatan",
     "back": "Melindungi kaki dari tertimpa, tertusuk, dan tergelincir.",
     "image": "media/kartu-02-4.svg"
    },
    {
     "front": "Pelindung telinga",
     "back": "Earplug atau earmuff wajib di area bising.",
     "image": "media/kartu-02-5.svg"
    },
    {
     "front": "Full body harness",
     "back": "Menahan tubuh bila terjatuh saat bekerja di ketinggian. Kaitkan pada titik angkur yang kuat.",
     "image": "media/kartu-02-6.svg"
    }
   ]
  },
  {
   "id": "s_bahaya",
   "type": "hotspot",
   "title": "Temukan kondisi tidak aman",
   "narration": "",
   "audio": null,
   "intro": "Ada **5 kondisi tidak aman** di bengkel ini. Ketuk bagian gambar yang menurut Anda berbahaya.",
   "image": "media/hotspot-03.svg",
   "imageAlt": "Ilustrasi area bengkel dengan beberapa kondisi tidak aman",
   "mode": "cari",
   "requireAll": false,
   "radius": 10,
   "points": [
    {
     "x": 22.5,
     "y": 84,
     "title": "Tumpahan oli",
     "text": "Risiko tergelincir. Segera bersihkan dengan absorben dan pasang tanda peringatan."
    },
    {
     "x": 55,
     "y": 86,
     "title": "Kabel terkelupas melintang",
     "text": "Risiko tersandung dan tersengat listrik. Matikan sumber listrik, ganti kabel, rapikan jalurnya."
    },
    {
     "x": 84,
     "y": 50,
     "title": "Tangga tidak diamankan",
     "text": "Tangga bersandar tanpa diikat/dipegangi. Amankan bagian atas atau pakai tangga dengan pengunci."
    },
    {
     "x": 13.5,
     "y": 54,
     "title": "Tabung gas tidak dirantai",
     "text": "Tabung bisa roboh dan katupnya patah. Ikat tabung tegak dengan rantai pada dinding/troli."
    },
    {
     "x": 26,
     "y": 52,
     "title": "APAR terhalang kardus",
     "text": "Alat pemadam harus mudah dijangkau. Singkirkan barang yang menghalangi."
    }
   ]
  },
  {
   "id": "s_loto",
   "type": "sort",
   "title": "Urutan Lockout/Tagout (LOTO)",
   "narration": "",
   "audio": null,
   "intro": "Sebelum memperbaiki unit, energinya harus diisolasi. Susun langkah LOTO berikut sesuai urutan yang benar.",
   "items": [
    "Beri tahu pihak terkait bahwa unit akan diisolasi",
    "Matikan unit dengan cara normal",
    "Isolasi semua sumber energi",
    "Pasang gembok dan tag pada titik isolasi",
    "Lepaskan atau tahan energi tersisa (tekanan, pegas, kapasitor)",
    "Verifikasi: coba nyalakan untuk memastikan unit benar-benar mati"
   ],
   "feedback": "Verifikasi adalah langkah terakhir yang paling sering dilupakan — jangan dilewati."
  },
  {
   "id": "s_kuis",
   "type": "quiz",
   "title": "Uji pemahaman",
   "narration": "",
   "audio": null,
   "intro": "Jawab semua soal. Nilai lulus 80.",
   "shuffle": true,
   "questions": [
    {
     "id": "s_kuis_q1",
     "type": "single",
     "text": "Dalam hierarki pengendalian risiko, APD berada di urutan…",
     "options": [
      "Pertama",
      "Kedua",
      "Terakhir",
      "Tidak termasuk hierarki"
     ],
     "correct": [
      2
     ],
     "feedback": "APD adalah lapisan pertahanan terakhir."
    },
    {
     "id": "s_kuis_q2",
     "type": "multi",
     "text": "Mana saja yang termasuk kondisi tidak aman di bengkel tadi? (pilih semua yang benar)",
     "options": [
      "Tumpahan oli di lantai",
      "Tabung gas yang tidak dirantai",
      "Rak barang yang tertata rapi",
      "APAR yang terhalang barang"
     ],
     "correct": [
      0,
      1,
      3
     ],
     "feedback": "Rak yang tertata rapi bukan kondisi tidak aman."
    },
    {
     "id": "s_kuis_q3",
     "type": "tf",
     "text": "Helm yang retak halus masih boleh dipakai untuk pekerjaan ringan.",
     "options": [
      "Benar",
      "Salah"
     ],
     "correct": [
      1
     ],
     "feedback": "Helm retak tidak lagi mampu menahan benturan. Segera ganti."
    }
   ]
  }
 ],
 "builtWith": "Studio SCORM",
 "builtAt": "2026-10-14T11:49:40.070Z"
};
